readme
-----

PB 28/9/2021

parameter maps

11 parameter maps from calibration of 16 stations

for each parameter a map which is read into cwatm
(at them moment also params_normalStorageLimit.map is read in, even if it is not used)
